package com.foxnetis.anipv;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class pvanime extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pvanime);
    }

    public  void vid_1 (View view){
        Intent pindah = new Intent(this, vid_1.class);
        startActivity(pindah);
    }
}
