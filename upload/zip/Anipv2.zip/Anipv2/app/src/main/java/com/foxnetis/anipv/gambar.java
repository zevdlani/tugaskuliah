package com.foxnetis.anipv;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class gambar extends AppCompatActivity {

    WebView webgambar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gambar);

        webgambar = (WebView)findViewById(R.id.liatgambar);
        webgambar.loadUrl("https://dev.foxnetis.com/anipv.php");
    }

}
