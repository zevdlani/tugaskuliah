package com.foxnetis.anipv;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener, View.OnClickListener {
    ImageView logo;
    TextView textusername,textpassword;
    EditText usernameinput, passwordinput;
    Button login;
    CheckBox cekbox;
    String username = "admin";
    String password = "admin";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        logo =(ImageView) findViewById(R.id.logo);
        usernameinput =(EditText) findViewById(R.id.usernameinput);
        passwordinput =(EditText) findViewById(R.id.passwordinput);
        login = (Button) findViewById(R.id.login);
        cekbox = (CheckBox) findViewById(R.id.cekbox);
        textusername =(TextView) findViewById(R.id.textusername);
        textpassword =(TextView) findViewById(R.id.textpassword);

        login.setOnClickListener(this);
        cekbox.setOnCheckedChangeListener(this);
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.login:
                String userku = usernameinput.getText().toString();
                String passku = passwordinput.getText().toString();
                if (username.equals(userku)&&password.equals(passku)){
                    Toast.makeText(this,"login Berhasil :)", Toast.LENGTH_SHORT).show();
                    Intent pindah = new Intent(this, dashboard.class);
                    startActivity(pindah);
                }
                else {
                    Toast.makeText(this,"Password atau Username Salah :(", Toast.LENGTH_LONG).show();
                }

        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

        if (!isChecked) {
            passwordinput.setTransformationMethod(PasswordTransformationMethod.getInstance());
        } else {
            passwordinput.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
        }

    }
}
